package com.company;

import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        double a = Math.random() * 100;
        long secret = Math.round(a) - 50;
        for (int i = 1; i > 0; i++) {
        System.out.println("Введите целое число от -50 до 50");
        Scanner scanner = new Scanner(System.in);
        double guess = scanner.nextInt();
        if (guess > secret) {
                System.out.println("Много");
            } else if (secret > guess){
                System.out.println("Мало");
            } else {
            System.out.println("Угадал");
            break;
        }
        }
    }

    }

