package com.company;

public class Main {

    public static void main(String[] args) {
        double a, b, c, absa, absb, absc, minabs;
        a = Math.random() * 100 - 50;
        b = Math.random() * 100 - 50;
        c = Math.random() * 100 - 50;
        System.out.println("Первое сгенерированное случайное число равно " + a);
        System.out.println("Второе сгенерированное случайное число равно " + b);
        System.out.println("Третье сгенерированное случайное число равно " + c);
        absa = Math.abs(a);
        absb = Math.abs(b);
        absc = Math.abs(c);

        if (absa == absb & absa == absc) {
            System.out.println("Все три сгенерированных случайных числа по модулю равны " + absa);
        } else {
            System.out.println("Все три сгенерированных случайных числа по модулю не равны между собой");
            minabs = Math.min(absa, absb);
            minabs = (absc <= minabs) ?
                    absc :
                    minabs;
            System.out.println("Наименьшее по модулю из трех сгенерированных случайных чисел по модулю равно  " + minabs);

        }
    }
}


