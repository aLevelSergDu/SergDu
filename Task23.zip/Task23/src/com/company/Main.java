package com.company;

public class Main {

    public static void main(String[] args) {
	double a = Math.random() * 100;
    long b = Math.round(a);
    double c = b % 2;
    if(c != 1) {
        System.out.println("Сгенерированное целое случайное число от 0 до 100 равно " + b + " и оно четное");
    } else {
        System.out.println("Сгенерированное целое случайное число от 0 до 100 равно " + b + " и оно нечетное");
    }

    }
}
