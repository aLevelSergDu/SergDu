package com.company;

public class Main {

    public static void main(String [] args) {
        int a = 897;
        System.out.println("Число " + a + " в двоичной системе счисления равно ");
        System.out.println(Integer.toString(a, 2));
    }
}
