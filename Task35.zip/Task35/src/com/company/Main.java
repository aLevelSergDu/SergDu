package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        for (int i = 1; i > 0; i++) {
            System.out.println("Введите число X ");
            Scanner scanner = new Scanner(System.in);
            double x = scanner.nextInt();
            System.out.println("Введите число Y ");
            Scanner scanne = new Scanner(System.in);
            double y = scanne.nextInt();
            System.out.println("Введите символ операции +, -, /, * ");
            Scanner scann = new Scanner(System.in);
            String oper = scann.nextLine();
            String a, b, c, d;
            a = "+";
            b = "-";
            c = "*";
            d = "/";
            if (oper.equals(a)) {
                System.out.println("Значение Z (cумма Х и У) равно " + (x + y));
            } else if (oper.equals(b)) {
                System.out.println("Значение Z (разность Х и У) равно " + (x - y));
            } else if (oper.equals(c)) {
                System.out.println("Значение Z (произведение чисел Х и У) равно " + (x * y));
            } else if (oper.equals(d) & (y != 0)) {
                System.out.println("Значение Z (результат деления Х на У) равно " + (x / y));
            } else if (oper.equals(d) & (y == 0)) {
                System.out.println("Операция деления на 0 не определена");
                break;
            } else {
                System.out.println("Вами введен некорректный символ арифметической операции");
            }

        }

                }
}



