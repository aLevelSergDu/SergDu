package com.company;

public class Main {

    public static void main(String[] args) {
        double a, b, c;
        long ax, bx, cx, absa, absb, absc, minabs;
        a = Math.random() * 100;
        b = Math.random() * 100;
        c = Math.random() * 100;
        ax = Math.round(a) - 50;
        bx = Math.round(b) - 50;
        cx = Math.round(c) - 50;
        System.out.println("Первое сгенерированное целое случайное число от -50 до 50 равно " + ax);
        System.out.println("Второе сгенерированное целое случаное число от -50 до 50 равно " + bx);
        System.out.println("Третье сгенерированное целое случайное число от -50 до 50 равно " + cx);
        absa = Math.abs(ax);
        absb = Math.abs(bx);
        absc = Math.abs(cx);

        if (absa == absb & absa == absc) {
            System.out.println("Все три сгенерированных случайных числа по модулю равны " + absa);
        } else {
            System.out.println("Все три сгенерированных случайных числа по модулю не равны между собой");

            minabs = Math.min(absa, absb);
            minabs = (absc <= minabs) ?
                    absc :
                    minabs;
            if (absa == absb & absa == minabs) {
                System.out.println("Указанное выше наименьшее по модулю значение принадлежит равным между собой по модулю Первому и Второму " +
                        "сгенерированным случайным числам");
            } else if (absa == absc & absa == minabs) {
                System.out.println("Указанное выше наименьшее значение принадлежит равным между собой по модулю Первому и Третьему " +
                        "сгенерированным случайным числам");
            } else if (absb == absc & absb == minabs) {
                System.out.println("Указанное выше наименьшее значение принадлежит равным между собой по модулю Второму и Третьему " +
                        "сгенерированным случайным числам");
            } else {
                System.out.println("Все три сгенерированных случайных числа по модулю не равны между собой попарно, наименьшее из них " +
                        "по модулю равно " + minabs);
                if(absa == minabs) {
                    System.out.println("Наименьшим по модулю из сгенерированных случайных чисел является Первое сгенерированное" +
                            " случайное число");
                }
                    else if (absb == minabs) {
                        System.out.println("Наименьшим по модулю из сгенерированных случайных чисел является Второе сгенерированное " +
                                "случайное число");
                    } else {
                        System.out.println("Наименьшим по модулю из сгененрированных случайных чисел является Третье сгенерированное" +
                                " случайное число");

                }
            }


        }
    }
}