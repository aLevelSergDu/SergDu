package com.company;

public class Main {

    public static void main(String[] args) {
        double a, b, c, x;
        String e = "";
        a = 897;
        x = a;
        if (a == 0) {
            System.out.println("Число 0 в двоичной системе счисления равно 0");
        } else {
            while (a >= 1) {
                b = a % 2;
                c = Math.floor(a / 2);
                e = e + Math.round(b);
                a = c;
            }
        }
        StringBuilder d = new StringBuilder(e);
        if (x != 0) {
            System.out.println("Число " + Math.round(x) + " в двоичной системе счисления равно " + d.reverse());
        }
    }
}

