package com.company;

public class Main {

    public static void main(String[] args) {
	double a, b, c, p, s;
    a = 3.0;
    b = 4.0;
    c = 5.0;
    p = (a + b + c) / 2;
    s = Math.pow(p * (p - a) * (p-b) * (p-c), 0.5);
    System.out.println(s);
    }
}
